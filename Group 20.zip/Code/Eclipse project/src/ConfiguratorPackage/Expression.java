/**
 */
package ConfiguratorPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ConfiguratorPackage.ConfiguratorPackagePackage#getExpression()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Expression extends NamedElement {
} // Expression
