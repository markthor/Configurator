/**
 */
package ConfiguratorPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ConfiguratorPackage.ConfiguratorPackagePackage#getValue()
 * @model abstract="true"
 * @generated
 */
public interface Value extends Expression {
} // Value
